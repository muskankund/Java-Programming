
class tommyvecetti{
	void hitting() {
		System.out.println("hitting");
	}
	void running() {
		System.out.println("running");
	}
	void firing() {
		System.out.println("firing");
	}
}

public class tommyvecettiClass {

	public static void main(String[] args) {
		tommyvecetti tv = new tommyvecetti();
		tv.hitting();
		tv.running();
		tv.firing();
	}

}
